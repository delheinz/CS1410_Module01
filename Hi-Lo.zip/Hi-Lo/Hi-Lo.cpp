#include <iostream>
#include <iomanip>
#include <time.h>
using namespace std;
int main() {
    srand(time(0));
    int card,comp,choice;
    int wins = 0;
    int losses = 0;


    do {
        card = rand()%16+1;
        comp = rand()%16+1;
        cout<<"Card Drawn: "<< card << endl;
        cout<<"1. The next card will be higher"<<endl;
        cout<<"2. The next card will be lower"<<endl;
        cout<<"3. Quit"<<endl;
        cout<<"Choose a number: "<<endl;
        cin>>choice;
        if(choice == 1 && choice < comp) {
            cout<<"You win"<<endl;
            wins += 1;
        }
        else if(choice == 1 && card > comp) {
            cout<<"You lose"<<endl;
            losses +=1;
        }
        if(choice == 2 && card < comp) {
            cout<<"You win"<<endl;
            losses += 1;
        }
        else if(choice == 2 && comp < card) {
            cout<<"You lose"<<endl;
            wins += 1;
        }
    }
    while(choice != 3);

    cout<<"Wins: "<<wins<<endl;
    cout<<"Losses: "<<losses<<endl;
    cout<<"Thanks for playing"<<endl;


    return 0;
}
